# Bus Station Project CSC186 UiTM

## Members :

| No.  | Contributor Names                      |
|------|----------------------------------------|
| 1.   | AMIRUL AKMAL BIN KHAIRUL IZWAN         |
| 2.   | MUHAMMAD AZWAR HARITH BIN NURUDDIN     |
| 3.   | NIK AHMAD DANIEAL BIN NIK LOKMAN HAKIM |
| 4.   | MUHAMAD MUQRI AFIF BIN KHAIROLAMER     |

## Functions :

- Stores data into 2 Folder
  - Database - Store all Station's Data
  - Tickets - All generated tickets will be saved there
- This program manages all the station available
  - Add station
  - Remove station
  - Price for the ticket is a sum of 2 station
- Produces ticket for the passengers
  - Generate ticket
  - Find ticket using IC